import json
import requests


url = "https://x.gloat.com/api/v1/jobs/?companyId=25923"
response = requests.get(url)
print(response.content)
json_response = json.loads(response.text)
print(json_response[45]['title'])
assert json_response[45]['title'] == 'QA Engineer'
