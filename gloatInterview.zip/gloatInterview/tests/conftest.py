import pytest
from selenium import webdriver


@pytest.fixture(scope="class")
def setup(request):
    driver = webdriver.Chrome("C:\\Users\\RanSimon\\PycharmProjects\\gloatInterview\\drivers\\chromedriver.exe")
    url = 'https://x.gloat.com/careers/all'
    driver.get(url)
    driver.maximize_window()
    request.cls.driver = driver
    yield
    driver.close()