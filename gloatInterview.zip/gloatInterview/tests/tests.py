import time
from utilities.BaseClass import BaseClass


class Tests(BaseClass):

    def test_e2e(self):
        # open Location drop-down
        self.driver.find_element_by_xpath("//div[@data-name='location-filter']").click()
        # choose Tel Aviv
        self.driver.find_element_by_xpath("//p[.='Tel Aviv']").click()
        time.sleep(2)
        # open department drop-down
        self.driver.find_element_by_xpath("//div[@data-name='department-filter']").click()
        time.sleep(2)
        #choose R&D
        self.driver.find_element_by_xpath("//div[@data-name='department-filter-option']/p[.='R&D']").click()
        # Verify that only R&D positions are displayed on the screen
        departmentCheck = self.driver.find_elements_by_xpath("//div[@data-name='job-department']/p[.='R&D']")
        departments = []
        for i in departmentCheck:
            departments.append(i.text)
        # Enter "QA" to the search bar
        self.driver.find_element_by_css_selector("input[placeholder='Search']").send_keys("QA")
        # get the text of the position that you got
        jobtitle = self.driver.find_element_by_css_selector("div[data-name='job-title']").text
        # click on QA Engineer position
        self.driver.find_element_by_xpath("//h1[.='QA Engineer']").click()
        time.sleep(2)
        # Get the current position text
        jobClicked = self.driver.find_element_by_xpath("//h2[.='QA Engineer']").text

        # test case 6 - only R&D positions were returned after using the filter "department"
        assert "R&D" in departments
        # check if all items in the list are equal to "R&D"
        print(all(d == 'R&D' for d in departments))
        # test case - 7 - checking search bar functionality
        assert "QA" in jobtitle
        # test case 8 - check the clicked job name
        assert "QA Engineer" == jobClicked

